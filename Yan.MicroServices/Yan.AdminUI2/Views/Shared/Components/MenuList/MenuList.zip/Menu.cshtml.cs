using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Yan.AdminUI2.Models;

namespace Yan.AdminUI2.Views.Shared.Components.MenuList
{
    /// <summary>
    /// 
    /// </summary>
    [ViewComponent(Name = "MenuList")]
    public class MenuModel : ViewComponent
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IViewComponentResult> InvokeAsync()
        {
            List<ElMenu> menus = new List<ElMenu>()
            {
                new ElMenu("����һ","path","name1", "el-icon-menu","1","0" ),
                new ElMenu("����һ","path","name2","el-icon-location","2","1"),
                new ElMenu("ѡ��һ","/home/index2","index2","el-icon-location","3","2"),
                new ElMenu("ѡ���","/home/index3","index3","el-icon-location","4","2"),
                new ElMenu("�����","/path","name5","el-icon-location","5","1"),
                new ElMenu("������","path","name6","el-icon-location","6","1"),
                new ElMenu("ѡ��һ","/home/index2","name7","el-icon-location","7","6"),
                new ElMenu("ѡ���","/home/index2","name8","el-icon-location","8","6"),

                new ElMenu("������","path","name9", "el-icon-menu","9","0"),
                new ElMenu("����һ","path","name10","el-icon-location","10","9"),
                new ElMenu("ѡ��һ","/home/index2","name11","el-icon-location","11","10"),
                new ElMenu("ѡ���","/home/index2","name12","el-icon-location","12","10"),
                new ElMenu("�����","/path","name13","el-icon-location","13","9"),

                new ElMenu("������","/path","name", "el-icon-menu","14","0")
            };
            return View("Menu", menus);
        }
    }
}
